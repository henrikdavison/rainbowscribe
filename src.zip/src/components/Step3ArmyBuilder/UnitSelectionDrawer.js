import React, { useState } from 'react';
import { Fab, SwipeableDrawer, List, ListSubheader, Box, Typography, IconButton, Button, useTheme, useMediaQuery } from '@mui/material';
import { Plus, Minus, X } from 'lucide-react';

function UnitSelectionDrawer({ unitsByCategory, category = null, onSelectUnit, unitCounts, isFAB = false }) {
  const theme = useTheme();
  const [open, setOpen] = useState(false);
  const [selectedUnits, setSelectedUnits] = useState({});
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  const handleSelectUnit = (unit) => {
    setSelectedUnits((prevSelectedUnits) => {
      const newCount = (prevSelectedUnits[unit.name]?.count || 0) + 1;
      const newPoints = (prevSelectedUnits[unit.name]?.points || 0) + unit.points;
      return {
        ...prevSelectedUnits,
        [unit.name]: { count: newCount, points: newPoints },
      };
    });
    onSelectUnit(unit);
  };

  const handleDeselectUnit = (unit) => {
    setSelectedUnits((prevSelectedUnits) => {
      const currentCount = prevSelectedUnits[unit.name]?.count || 0;
      if (currentCount <= 1) {
        const { [unit.name]: _, ...remainingUnits } = prevSelectedUnits;
        return remainingUnits;
      } else {
        return {
          ...prevSelectedUnits,
          [unit.name]: {
            count: currentCount - 1,
            points: prevSelectedUnits[unit.name].points - unit.points,
          },
        };
      }
    });
  };

  return (
    <>
      {isFAB ? (
        <Fab
          color="primary"
          aria-label="view-all-units"
          onClick={() => setOpen(true)}
          sx={{ position: 'fixed', bottom: 16, right: 16 }}
        >
          <Plus size={24} />
        </Fab>
      ) : (
        <IconButton fontSize="small" sx={{ mr: 2 }} onClick={() => setOpen(true)}>
          <Plus size={18} />
        </IconButton>
      )}

      <SwipeableDrawer
        anchor="bottom"
        open={open}
        onClose={() => setOpen(false)}
        onOpen={() => setOpen(true)}
        PaperProps={{
          sx: {
            borderTopLeftRadius: 8,
            borderTopRightRadius: 8,
            height: '60vh',
            display: 'flex',
            flexDirection: 'column',
            bgcolor: theme.palette.background.default,
          },
        }}
      >
        {isMobile && (
          <Box sx={{ width: 40, height: 8, bgcolor: theme.palette.text.secondary, borderRadius: 4, alignSelf: 'center', marginTop: 1, marginBottom: 1 }} />
        )}

        <Box sx={{ flexGrow: 1, overflowY: 'auto', paddingBottom: 8 }}>
          <List>
            {category ? (
              <>
                <ListSubheader sx={{ bgcolor: theme.palette.background.default }}>
                  <Typography variant="overline" color="text.primary">
                    {category}
                  </Typography>
                </ListSubheader>
                {Array.isArray(unitsByCategory) && unitsByCategory.map((unit, index) => (
                  <Box key={index}>
                    <Typography>{unit.name}</Typography>
                    <IconButton onClick={() => handleSelectUnit(unit)}>+</IconButton>
                    {unitCounts[unit.name] > 0 && <IconButton onClick={() => handleDeselectUnit(unit)}>-</IconButton>}
                  </Box>
                ))}
              </>
            ) : (
              Object.entries(unitsByCategory).map(([categoryName, units]) => (
                <React.Fragment key={categoryName}>
                  <ListSubheader sx={{ bgcolor: theme.palette.background.default }}>
                    <Typography variant="overline" color="text.primary">
                      {categoryName}
                    </Typography>
                  </ListSubheader>
                  {units.map((unit, index) => (
                    <Box key={`${categoryName}-${index}`}>
                      <Typography>{unit.name}</Typography>
                      <IconButton onClick={() => handleSelectUnit(unit)}>+</IconButton>
                      {unitCounts[unit.name] > 0 && <IconButton onClick={() => handleDeselectUnit(unit)}>-</IconButton>}
                    </Box>
                  ))}
                </React.Fragment>
              ))
            )}
          </List>
        </Box>

        <Box sx={{ position: 'sticky', bottom: 0, bgcolor: theme.palette.background.default, p: 2 }}>
          <Button onClick={() => setOpen(false)} variant="contained" color="primary" size="large" fullWidth startIcon={<X size={24} />}>
            Close
          </Button>
        </Box>
      </SwipeableDrawer>
    </>
  );
}

export default UnitSelectionDrawer;
