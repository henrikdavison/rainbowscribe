import React, { useState, useEffect, useCallback } from 'react';
import { Box, Typography, Stack, useTheme } from '@mui/material';
import CategoryItem from './CategoryItem';
import UnitSelectionDrawer from './UnitSelectionDrawer';
import { categories, units } from '../../data/unitData';

function CategoryList({ onTotalPointsChange }) {
  const theme = useTheme();

  const [army, setArmy] = useState({
    'Epic Hero': [],
    'Character': [],
    'Battleline': [],
    'Vehicle': [],
    'Fortification': [],
    'Allied Units': [],
  });

  const [unitCounts, setUnitCounts] = useState({});

  // Memoized callback to prevent excessive re-renders
  const calculateTotalPoints = useCallback(() => {
    const totalPoints = Object.values(army).flat().reduce((acc, item) => acc + item.points, 0);
    onTotalPointsChange(totalPoints);
  }, [army, onTotalPointsChange]);

  useEffect(() => {
    calculateTotalPoints();
  }, [army, calculateTotalPoints]);

  const handleSelectUnit = (unit, category) => {
    setArmy((prevArmy) => ({
      ...prevArmy,
      [category]: [...(prevArmy[category] || []), { ...unit, id: Date.now() }],
    }));
    setUnitCounts((prevCounts) => ({
      ...prevCounts,
      [unit.name]: (prevCounts[unit.name] || 0) + 1,
    }));
  };

  const handleDeleteItem = (category, id, unitName) => {
    setArmy((prevArmy) => ({
      ...prevArmy,
      [category]: prevArmy[category].filter((item) => item.id !== id),
    }));
    setUnitCounts((prevCounts) => ({
      ...prevCounts,
      [unitName]: Math.max((prevCounts[unitName] || 1) - 1, 0),
    }));
  };

  return (
    <>
      <Stack borderColor={theme.palette.divider}>
        {categories.map((category) => {
          const unitsByCategory = units.filter(unit => unit.categories.includes(category.name));
          return (
            <Box key={category.name} marginTop={2}>
              <Box display="flex" justifyContent="space-between" alignItems="center">
                <Typography variant="overline" paddingLeft={2}>{category.name}</Typography>
                <UnitSelectionDrawer
                  unitsByCategory={unitsByCategory}
                  category={category.name}
                  onSelectUnit={(unit) => handleSelectUnit(unit, category.name)}
                  unitCounts={unitCounts}
                  isFAB={false}
                />
              </Box>
              <Stack>
                {army[category.name].map((item) => (
                  <CategoryItem
                    key={item.id}
                    name={item.name}
                    points={item.points}
                    count={unitCounts[item.name] || 0}
                    onDelete={() => handleDeleteItem(category.name, item.id, item.name)}
                    isLastItem={item === army[category.name][army[category.name].length - 1]}
                  />
                ))}
              </Stack>
            </Box>
          );
        })}
      </Stack>

      {/* FAB Drawer for all units */}
      <UnitSelectionDrawer
        unitsByCategory={units} // Ensure `units` is passed correctly as an array
        onSelectUnit={(unit) => handleSelectUnit(unit, Object.keys(units).find((key) => units[key].includes(unit)))}
        unitCounts={unitCounts}
        isFAB={true}
      />
    </>
  );
}

export default CategoryList;
