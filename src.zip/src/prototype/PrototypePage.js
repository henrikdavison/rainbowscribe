import React from 'react';
import { Box, Typography, Button, Stack } from '@mui/material';

const Prototype = () => 
    <Box p={2} textAlign="center">
      <Typography variant="h5" gutterBottom>
        Select Game Type
      </Typography>
    </Box>
};
}

export default Prototype;
