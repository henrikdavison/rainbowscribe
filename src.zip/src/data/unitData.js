// src/data/unitData.js

export const units = [
  {
    name: "Baharroth",
    points: 125,
    selections: ["Fury of the Tempest", "The Shining Blade"],
    categories: ["Epic Hero", "Character", "Infantry", "Grenades", "Fly", "Phoenix Lord", "Baharroth", "Faction: Aeldari"],
    rules: ["Assault", "Deep Strike", "Leader", "Lethal Hits", "Strands of Fate", "Sustained Hits"],
    abilities: [
      { name: "Cloudstrider", description: "In your Shooting phase, after this model’s unit has shot..." },
      { name: "Cry of the Wind", description: "While this model is leading a unit, each time a model in that unit makes an attack, add 1 to the Hit roll." },
      { name: "Invulnerable Save (Phoenix Lord)", description: "Baharroth has a 4+ Invulnerable save." },
      { name: "Leader", description: "This model can be attached to the following unit: Swooping Hawks" }
    ],
    weapons: {
      melee: [
        { name: "The Shining Blade", range: "Melee", attacks: 6, ws: "2+", strength: 5, ap: -2, damage: 2, keywords: ["Sustained Hits 1"] }
      ],
      ranged: [
        { name: "Fury of the Tempest", range: "24\"", attacks: 4, bs: "2+", strength: 6, ap: -1, damage: 2, keywords: ["Assault", "Lethal Hits"] }
      ]
    },
    stats: {
      movement: "14\"",
      toughness: 3,
      save: "2+",
      wounds: 5,
      leadership: "6+",
      oc: 1
    }
  },
  {
    name: "Fuegan",
    points: 130,
    selections: ["Searsong", "The Fire Axe"],
    categories: ["Character", "Epic Hero", "Infantry", "Phoenix Lord", "Fuegan", "Faction: Aeldari"],
    rules: ["Feel No Pain 5+", "Leader", "Melta", "Strands of Fate", "Sustained Hits"],
    abilities: [
      { name: "Burning Lance", description: "While this model is leading a unit, each time a model in that unit makes an attack, add 1 to the Hit roll." },
      { name: "Invulnerable Save (Phoenix Lord)", description: "Fuegan has a 4+ Invulnerable save." },
      { name: "Leader", description: "This model can be attached to the following unit: Fire Dragons" },
      { name: "Unquenchable Resolve", description: "The first time this model is destroyed, roll one D6 at the end of the phase..." }
    ],
    weapons: {
      melee: [
        { name: "The Fire Axe", range: "Melee", attacks: 6, ws: "2+", strength: 5, ap: -4, damage: 3 }
      ],
      ranged: [
        { name: "Searsong - Beam", range: "12\"", attacks: 3, bs: "2+", strength: 8, ap: -3, damage: 2, keywords: ["Sustained Hits D3"] },
        { name: "Searsong - Lance", range: "18\"", attacks: 1, bs: "2+", strength: 14, ap: -4, damage: "D6", keywords: ["Melta 6"] }
      ]
    },
    stats: {
      movement: "7\"",
      toughness: 3,
      save: "2+",
      wounds: 5,
      leadership: "6+",
      oc: 1
    }
  },
  {
    name: "Farseer",
    points: 80,
    selections: ["Eldritch Storm", "Shuriken Pistol", "Witchblade"],
    categories: ["Character", "Infantry", "Psyker", "Farseer", "Faction: Aeldari"],
    rules: ["Anti-", "Assault", "Blast", "Leader", "Pistol", "Psychic", "Strands of Fate"],
    abilities: [
      { name: "Branching Fates (psychic)", description: "Once per turn, when you use a Fate dice to substitute a roll made for a model..." },
      { name: "Fortune (Psychic)", description: "In your Command phase, you can roll one D6: on a 2+, select one friendly AELDARI unit..." },
      { name: "Invulnerable Save (Farseer)", description: "A Farseer has a 4+ Invulnerable save." },
      { name: "Leader", description: "This model can be attached to the following units: Guardian Defenders, Storm Guardians, Warlock Conclave" }
    ],
    weapons: {
      melee: [
        { name: "Witchblade", range: "Melee", attacks: 2, ws: "3+", strength: 3, ap: 0, damage: 2, keywords: ["Anti-Infantry 2+", "Psychic"] }
      ],
      ranged: [
        { name: "Eldritch Storm", range: "24\"", attacks: "D6", bs: "3+", strength: 6, ap: -2, damage: "D3", keywords: ["Blast", "Psychic"] },
        { name: "Shuriken Pistol", range: "12\"", attacks: 1, bs: "2+", strength: 4, ap: -1, damage: 1, keywords: ["Assault", "Pistol"] }
      ]
    },
    stats: {
      movement: "7\"",
      toughness: 3,
      save: "6+",
      wounds: 4,
      leadership: "6+",
      oc: 1
    }
  },
  {
    name: "Autarch",
    points: 75,
    selections: ["Shuriken Pistol", "Star Glaive"],
    categories: ["Character", "Infantry", "Aeldari", "Faction: Aeldari"],
    rules: ["Assault", "Leader", "Pistol", "Strands of Fate"],
    abilities: [
      { name: "Invulnerable Save (Autarch)", description: "An Autarch has a 4+ Invulnerable save." },
      { name: "Leader", description: "This model can be attached to the following units: Guardian Defenders, Storm Guardians" },
      { name: "Path of Command", description: "At the start of your Command phase, if this model is your Warlord and is on the battlefield, you gain 1CP." },
      { name: "Superlative Strategist", description: "Once per turn, you can target this model's unit with a Stratagem even if you have already used that Stratagem on a different unit this phase." }
    ],
    weapons: {
      melee: [
        { name: "Star Glaive", range: "Melee", attacks: 5, ws: "3+", strength: 6, ap: -2, damage: 2 }
      ],
      ranged: [
        { name: "Shuriken Pistol", range: "12\"", attacks: 1, bs: "2+", strength: 4, ap: -1, damage: 1, keywords: ["Assault", "Pistol"] }
      ]
    },
    stats: {
      movement: "7\"",
      toughness: 3,
      save: "3+",
      wounds: 4,
      leadership: "6+",
      oc: 1
    }
  },
  {
    name: "Guardian Defenders",
    points: 100,
    selections: ["10x Guardian Defender", "Heavy Weapon Platform"],
    categories: ["Battleline", "Infantry", "Faction: Aeldari"],
    abilities: [
      { name: "Defense Tactics", description: "Guardian Defenders may re-roll failed hit rolls while in cover." }
    ],
    weapons: {
      ranged: [
        { name: "Shuriken Catapult", range: "18\"", attacks: 1, bs: "3+", strength: 4, ap: 0, damage: 1, keywords: ["Assault"] },
        { name: "Shuriken Cannon", range: "24\"", attacks: 3, bs: "3+", strength: 6, ap: -1, damage: 2 }
      ]
    },
    stats: {
      movement: "7\"",
      toughness: 3,
      save: "5+",
      wounds: 1,
      leadership: "7+",
      oc: 1
    }
  },
  {
    name: "Storm Guardians",
    points: 100,
    selections: ["10x Storm Guardian"],
    categories: ["Battleline", "Infantry", "Faction: Aeldari"],
    abilities: [
      { name: "Fury of the Storm", description: "Gain +1 Attack on the charge." }
    ],
    weapons: {
      melee: [
        { name: "Close Combat Weapon", range: "Melee", attacks: 1, ws: "4+", strength: 3, ap: 0, damage: 1 }
      ],
      ranged: [
        { name: "Shuriken Pistol", range: "12\"", attacks: 1, bs: "4+", strength: 4, ap: 0, damage: 1 }
      ]
    },
    stats: {
      movement: "7\"",
      toughness: 3,
      save: "5+",
      wounds: 1,
      leadership: "7+",
      oc: 1
    }
  },
  {
    name: "Heavy Weapon Platform",
    points: 0,
    selections: ["Shuriken Cannon"],
    categories: ["Support", "Infantry", "Faction: Aeldari"],
    abilities: [
      { name: "Flexible Deployment", description: "May be deployed with Guardian Defenders as a support weapon." }
    ],
    weapons: {
      ranged: [
        { name: "Shuriken Cannon", range: "24\"", attacks: 3, bs: "3+", strength: 6, ap: -1, damage: 2 }
      ]
    },
    stats: {
      movement: "7\"",
      toughness: 3,
      save: "3+",
      wounds: 2,
      leadership: "7+",
      oc: 0
    }
  }
];

export const categories = [
  { name: 'Epic Hero', items: [] },
  { name: 'Character', items: [] },
  { name: 'Battleline', items: [] },
  { name: 'Vehicle', items: [] },
  { name: 'Fortification', items: [] },
  { name: 'Allied Units', items: [] },
];
